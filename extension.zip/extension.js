import St from 'gi://St';
import GObject from 'gi://GObject';
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import Clutter from 'gi://Clutter';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';


function makeDirectoryAsync(file) {
    return new Promise((resolve, reject) => {
        file.make_directory_async(GLib.PRIORITY_DEFAULT, null, (_f, res) => {
            try {
                file.make_directory_finish(res);
                resolve();
            }
            catch (err) {
                reject(err);
            }
        });
    });
}
async function makeDirectoryWithParentsAsync(file) {
    try {
        await makeDirectoryAsync(file);
    }
    catch (err) {
        if (err.code === Gio.IOErrorEnum.EXISTS) {
            return;
        }
        if (err.code === Gio.IOErrorEnum.NOT_FOUND) {
            const parent = file.get_parent();
            if (!parent) {
                throw err;
            }
            await makeDirectoryWithParentsAsync(parent);
            try {
                await makeDirectoryAsync(file);
            }
            catch (err2) {
                if (err2.code !== Gio.IOErrorEnum.EXISTS) {
                    throw err2;
                }
            }
            return;
        }
        throw err;
    }
}

function loadFileContentsAsync(file) {
    return new Promise((resolve, reject) => {
        file.load_contents_async(null, (_f, res) => {
            try {
                resolve(file.load_contents_finish(res));
            }
            catch (err) {
                reject(err);
            }
        });
    });
}

function createFileAsync(file) {
    return new Promise((resolve, reject) => {
        file.create_async(Gio.FileCreateFlags.NONE, GLib.PRIORITY_DEFAULT, null, (_f, res) => {
            try {
                const stream = file.create_finish(res);
                stream.close(null);
                resolve();
            }
            catch (err) {
                reject(err);
            }
        });
    });
}

function logError(msg, err) {
    console.error(msg, err);
}

const TodoWidget = GObject.registerClass(class TodoWidget extends St.BoxLayout {
    _settings;
    _intervalId = null;
    _fileMonitor = null;
    _filePath = '';
    _dragging = false;
    _dragX = 0;
    _dragY = 0;
    _headerBox;
    _tasksScrollView;
    _tasksBox;
    _addBox;
    _addEntry;
    _lockButtonIcon;
    constructor(settings) {
        super({
            style_class: 'todo-widget-container',
            vertical: true,
            reactive: true,
            can_focus: true,
        });
        this._settings = settings;
        this._buildUI();
        this._connectSettings();
        this._updatePosition();
        this._updateFilePath();
        this._updateTodoList();
        this._startUpdates();
    }

    _buildUI() {
        this._updateContainerStyle();
        this.connect('button-press-event', (actor, event) => this._onButtonPress(event));
        this.connect('motion-event', (actor, event) => this._onMotion(event));
        this.connect('button-release-event', (actor, event) => this._onButtonRelease(event));
        this._headerBox = new St.BoxLayout({
            style_class: 'todo-header',
            vertical: false,
            x_expand: true,
        });
        const title = new St.Label({
            text: 'TODO LIST',
            style_class: 'todo-title',
            y_align: Clutter.ActorAlign.CENTER,
            x_expand: true,
        });
        this._headerBox.add_child(title);
        const addButton = new St.Button({
            style_class: 'todo-header-button',
            reactive: true,
            can_focus: true,
            child: new St.Icon({
                icon_name: 'list-add-symbolic',
                icon_size: 14,
            }),
        });
        addButton.connect('clicked', () => {
            this._toggleAddBox();
        });
        this._headerBox.add_child(addButton);
        const openButton = new St.Button({
            style_class: 'todo-header-button',
            reactive: true,
            can_focus: true,
            child: new St.Icon({
                icon_name: 'document-open-symbolic',
                icon_size: 14,
            }),
        });
        openButton.connect('clicked', () => {
            this._openTodoFile();
        });
        this._headerBox.add_child(openButton);
        const clearButton = new St.Button({
            style_class: 'todo-header-button',
            reactive: true,
            can_focus: true,
            child: new St.Icon({
                icon_name: 'edit-clear-symbolic',
                icon_size: 14,
            }),
        });
        clearButton.connect('clicked', () => {
            this._clearCompletedTasks();
        });
        this._headerBox.add_child(clearButton);
        const lockButton = new St.Button({
            style_class: 'todo-header-button',
            reactive: true,
            can_focus: true,
        });
        const isLocked = this._settings.get_boolean('lock-position');
        this._lockButtonIcon = new St.Icon({
            icon_name: isLocked ? 'changes-prevent-symbolic' : 'changes-allow-symbolic',
            icon_size: 14,
        });
        lockButton.set_child(this._lockButtonIcon);
        lockButton.connect('clicked', () => {
            const nextState = !this._settings.get_boolean('lock-position');
            this._settings.set_boolean('lock-position', nextState);
        });
        this._headerBox.add_child(lockButton);
        this.add_child(this._headerBox);
        this._tasksScrollView = new St.ScrollView({
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.AUTOMATIC,
            x_expand: true,
            y_expand: true,
        });
        this._tasksScrollView.set_style('max-height: 300px;');
        this._tasksBox = new St.BoxLayout({
            style_class: 'todo-tasks-list',
            vertical: true,
            x_expand: true,
        });
        this._tasksScrollView.set_child(this._tasksBox);
        this.add_child(this._tasksScrollView);
        this._addBox = new St.BoxLayout({
            vertical: true,
            x_expand: true,
            visible: false,
        });
        this._addEntry = new St.Entry({
            style_class: 'todo-add-entry',
            hint_text: 'Add a task...',
            x_expand: true,
            reactive: true,
            can_focus: true,
        });
        this._addEntry.clutter_text.connect('activate', () => {
            const text = this._addEntry.get_text().trim();
            if (text) {
                this._addTask(text);
                this._addEntry.set_text('');
                this._toggleAddBox();
            }
        });
        this._addEntry.clutter_text.connect('key-press-event', (actor, event) => {
            const symbol = event.get_key_symbol();
            if (symbol === Clutter.KEY_Escape) {
                this._toggleAddBox();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });
        this._addBox.add_child(this._addEntry);
        this.add_child(this._addBox);
    }

    _connectSettings() {
        this._settings.connectObject('changed::position-x', () => this._updatePosition(), 'changed::position-y', () => this._updatePosition(), this);
        const styleKeys = [
            'theme',
            'background-color',
            'border-color',
            'text-color',
            'border-radius',
            'padding-horizontal',
            'padding-vertical',
            'label-font-size',
        ];
        styleKeys.forEach((key) => {
            this._settings.connectObject(`changed::${key}`, () => {
                this._updateContainerStyle();
                this._updateTodoList();
            }, this);
        });
        this._settings.connectObject('changed::todo-file-path', () => {
            this._updateFilePath();
            this._updateTodoList();
        }, 'changed::update-interval', () => {
            this._startUpdates();
        }, 'changed::show-completed', () => {
            this._updateTodoList();
        }, 'changed::completed-behavior', () => {
            this._updateTodoList();
        }, 'changed::lock-position', () => {
            this._updateLockIcon();
        }, this);
    }

    _updateContainerStyle() {
        const theme = this._settings.get_string('theme');
        const themes = ['dark', 'light', 'dracula', 'nord', 'gruvbox', 'system'];
        themes.forEach((t) => this.remove_style_class_name(t));
        this.add_style_class_name(theme);
        this.set_style('');
        const borderRadius = this._settings.get_int('border-radius');
        const padH = this._settings.get_int('padding-horizontal');
        const padV = this._settings.get_int('padding-vertical');
        let inlineStyle = `
        border-radius: ${borderRadius}px;
        padding: ${padV}px ${padH}px;
      `;
        if (theme === 'custom') {
            const bgColor = this._settings.get_string('background-color');
            const borderColor = this._settings.get_string('border-color');
            inlineStyle += `
          background-color: ${bgColor};
          border: 1px solid ${borderColor};
        `;
        }
        this.set_style(inlineStyle);
    }

    _updateLockIcon() {
        if (!this._lockButtonIcon)
            return;
        const isLocked = this._settings.get_boolean('lock-position');
        this._lockButtonIcon.icon_name = isLocked ? 'changes-prevent-symbolic' : 'changes-allow-symbolic';
    }

    _updatePosition() {
        const monitor = Main.layoutManager.primaryMonitor;
        if (!monitor)
            return;
        const x = (monitor.width * this._settings.get_double('position-x')) / 100;
        const y = (monitor.height * this._settings.get_double('position-y')) / 100;
        this.set_position(Math.round(x), Math.round(y));
    }

    _startUpdates() {
        this._clearTimer();
        const interval = this._settings.get_int('update-interval');
        if (interval <= 0)
            return;
        this._intervalId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, interval, () => {
            this._updateTodoList();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _clearTimer() {
        if (this._intervalId !== null) {
            GLib.source_remove(this._intervalId);
            this._intervalId = null;
        }
    }

    _updateFilePath() {
        let path = this._settings.get_string('todo-file-path');
        if (path.startsWith('~/')) {
            path = GLib.get_home_dir() + path.slice(1);
        }
        this._filePath = path;
        if (this._fileMonitor) {
            this._fileMonitor.disconnectObject(this);
            this._fileMonitor.cancel();
            this._fileMonitor = null;
        }
        const file = Gio.File.new_for_path(this._filePath);
        const parent = file.get_parent();
        if (parent) {
            makeDirectoryWithParentsAsync(parent)
                .then(() => {
                return createFileAsync(file);
            })
                .then(() => {
                try {
                    this._setupFileMonitor(file);
                    this._updateTodoList();
                }

                catch (monitorErr) {
                    logError('[TodoWidget] Failed to monitor file:', monitorErr);
                }
            })
                .catch((err) => {
                if (err.code !== Gio.IOErrorEnum.EXISTS) {
                    logError('[TodoWidget] Failed to initialize file:', err);
                }
                try {
                    this._setupFileMonitor(file);
                    this._updateTodoList();
                }

                catch (monitorErr) {
                    logError('[TodoWidget] Failed to monitor file:', monitorErr);
                }
            });
        }
        else {
            try {
                this._setupFileMonitor(file);
                this._updateTodoList();
            }

            catch (monitorErr) {
                logError('[TodoWidget] Failed to monitor file:', monitorErr);
            }
        }
    }

    _setupFileMonitor(file) {
        if (this._fileMonitor) {
            this._fileMonitor.disconnectObject(this);
            this._fileMonitor.cancel();
        }
        this._fileMonitor = file.monitor_file(Gio.FileMonitorFlags.NONE, null);
        this._fileMonitor.connectObject('changed', (mon, f, otherF, eventType) => {
            if (eventType === Gio.FileMonitorEvent.CHANGES_DONE_HINT ||
                eventType === Gio.FileMonitorEvent.CREATED) {
                this._updateTodoList();
            }
        }, this);
    }
    async _updateTodoList() {
        try {
            const file = Gio.File.new_for_path(this._filePath);
            try {
                const [success, contents] = await loadFileContentsAsync(file);
                if (success) {
                    const decoder = new TextDecoder('utf-8');
                    const text = decoder.decode(contents);
                    const lines = text.split('\n').filter((line) => line.trim().length > 0);
                    this._renderTasks(lines);
                }
                else {
                    this._renderTasks(['Failed to read tasks file.']);
                }
            }

            catch (err) {
                if (err.code === Gio.IOErrorEnum.NOT_FOUND) {
                    this._renderTasks(['No tasks file found. Click + to start.']);
                }
                else {
                    logError('[TodoWidget] Error loading contents:', err);
                    this._renderTasks([`Error reading tasks file`]);
                }
            }
        }

        catch (err) {
            logError('[TodoWidget] Error updating todo list:', err);
            this._renderTasks([`Error: ${err}`]);
        }
    }

    _renderTasks(tasks) {
        this._tasksBox.destroy_all_children();
        const theme = this._settings.get_string('theme');
        const fontSize = this._settings.get_int('label-font-size');
        const textColor = this._settings.get_string('text-color');
        const showCompleted = this._settings.get_boolean('show-completed');
        let taskCount = 0;
        tasks.forEach((task, index) => {
            const isCompleted = task.trim().startsWith('x ');
            if (isCompleted && !showCompleted) {
                return;
            }
            const taskText = isCompleted ? task.trim().slice(2) : task;
            const row = new St.BoxLayout({
                style_class: 'todo-task-row',
                vertical: false,
                x_expand: true,
            });
            const checkbox = new St.Button({
                style_class: 'todo-checkbox',
                reactive: true,
                can_focus: true,
                child: new St.Icon({
                    icon_name: isCompleted ? 'checkbox-checked-symbolic' : 'checkbox-symbolic',
                    icon_size: fontSize + 2,
                    style: theme === 'custom' ? `color: ${textColor};` : '',
                }),
            });
            checkbox.connect('clicked', () => {
                this._toggleTaskCompleted(index);
            });
            row.add_child(checkbox);
            const label = new St.Label({
                text: taskText,
                style_class: isCompleted ? 'todo-task-text-completed' : 'todo-task-text',
                style: theme === 'custom'
                    ? `font-size: ${fontSize}px; color: ${textColor};`
                    : `font-size: ${fontSize}px;`,
                y_align: Clutter.ActorAlign.CENTER,
                x_expand: true,
            });
            row.add_child(label);
            this._tasksBox.add_child(row);
            taskCount++;
        });
        if (taskCount === 0) {
            const emptyLabel = new St.Label({
                text: 'No tasks left!',
                style_class: 'todo-task-text-completed',
                style: theme === 'custom'
                    ? `font-size: ${fontSize}px; color: ${textColor}; margin: 8px 0;`
                    : `font-size: ${fontSize}px; margin: 8px 0;`,
                x_expand: true,
                y_align: Clutter.ActorAlign.CENTER,
            });
            this._tasksBox.add_child(emptyLabel);
        }
    }

    _toggleAddBox() {
        const isVisible = this._addBox.visible;
        this._addBox.visible = !isVisible;
        if (this._addBox.visible) {
            this._addEntry.grab_key_focus();
        }
    }

    _openTodoFile() {
        try {
            const file = Gio.File.new_for_path(this._filePath);
            Gio.AppInfo.launch_default_for_uri_async(file.get_uri(), null, null, null);
        }

        catch (err) {
            logError('[TodoWidget] Error launching default editor:', err);
        }
    }
    async _addTask(text) {
        try {
            const file = Gio.File.new_for_path(this._filePath);
            let contents = '';
            try {
                const [success, rawContents] = await loadFileContentsAsync(file);
                if (success) {
                    const decoder = new TextDecoder('utf-8');
                    contents = decoder.decode(rawContents);
                }
            }

            catch (err) {
                if (err.code !== Gio.IOErrorEnum.NOT_FOUND) {
                    logError('[TodoWidget] Failed to load contents for add:', err);
                }
            }
            const separator = contents.endsWith('\n') || contents === '' ? '' : '\n';
            const newContents = contents + separator + text + '\n';
            await this._writeTodoFile(this._filePath, newContents);
        }

        catch (err) {
            logError('[TodoWidget] Error adding task:', err);
        }
    }
    async _toggleTaskCompleted(index) {
        try {
            const file = Gio.File.new_for_path(this._filePath);
            let contents = '';
            try {
                const [success, rawContents] = await loadFileContentsAsync(file);
                if (!success)
                    return;
                const decoder = new TextDecoder('utf-8');
                contents = decoder.decode(rawContents);
            }

            catch (err) {
                if (err.code !== Gio.IOErrorEnum.NOT_FOUND) {
                    logError('[TodoWidget] Error reading file for toggle completed:', err);
                }

                return;
            }
            const lines = contents.split('\n');
            let taskIndex = 0;
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].trim().length > 0) {
                    if (taskIndex === index) {
                        const completedBehavior = this._settings.get_string('completed-behavior');
                        if (completedBehavior === 'delete') {
                            lines.splice(i, 1);
                        }
                        else {
                            const lineTrimmed = lines[i].trim();
                            if (lineTrimmed.startsWith('x ')) {
                                lines[i] = lineTrimmed.slice(2);
                            }
                            else {
                                lines[i] = 'x ' + lineTrimmed;
                            }
                        }

                        break;
                    }
                    taskIndex++;
                }
            }
            const newContents = lines.join('\n');
            await this._writeTodoFile(this._filePath, newContents);
        }

        catch (err) {
            logError('[TodoWidget] Error toggling task completed:', err);
        }
    }
    async _clearCompletedTasks() {
        try {
            const file = Gio.File.new_for_path(this._filePath);
            let contents = '';
            try {
                const [success, rawContents] = await loadFileContentsAsync(file);
                if (!success)
                    return;
                const decoder = new TextDecoder('utf-8');
                contents = decoder.decode(rawContents);
            }

            catch (err) {
                if (err.code !== Gio.IOErrorEnum.NOT_FOUND) {
                    logError('[TodoWidget] Error reading file for clear completed:', err);
                }

                return;
            }
            const lines = contents.split('\n');
            const newLines = lines.filter((line) => !line.trim().startsWith('x '));
            const newContents = newLines.join('\n');
            await this._writeTodoFile(this._filePath, newContents);
        }

        catch (err) {
            logError('[TodoWidget] Error clearing completed tasks:', err);
        }
    }
    async _writeTodoFile(path, content) {
        const file = Gio.File.new_for_path(path);
        const encoder = new TextEncoder();
        const bytes = encoder.encode(content);
        const gbytes = GLib.Bytes.new(bytes);
        const doWrite = () => {
            return new Promise((resolve, reject) => {
                file.replace_contents_bytes_async(gbytes, null, false, Gio.FileCreateFlags.REPLACE_DESTINATION, null, (_file, res) => {
                    try {
                        const [success] = file.replace_contents_finish(res);
                        if (success) {
                            resolve();
                        }
                        else {
                            reject(new Error('Failed to write contents'));
                        }
                    }

                    catch (e) {
                        reject(e);
                    }
                });
            });
        };
        try {
            await doWrite();
        }

        catch (err) {
            if (err.code === Gio.IOErrorEnum.NOT_FOUND) {
                const parent = file.get_parent();
                if (parent) {
                    try {
                        await makeDirectoryWithParentsAsync(parent);
                        await doWrite();
                        return;
                    }

                    catch (dirErr) {
                        logError('[TodoWidget] Failed to create directories for writing:', dirErr);
                        throw dirErr;
                    }
                }
            }
            throw err;
        }
    }

    _isInteractive(actor) {
        if (!actor)
            return false;
        try {
            const gtypeName = GObject.type_name(actor.constructor);
            if (gtypeName &&
                (gtypeName.includes('Button') ||
                    gtypeName.includes('Entry') ||
                    gtypeName.includes('Text') ||
                    gtypeName.includes('ScrollBar') ||
                    gtypeName.includes('ScrollView'))) {
                return true;
            }
        }

        catch (e) {
        }
        const className = actor.constructor.name;
        if (className &&
            (className.includes('Button') ||
                className.includes('Entry') ||
                className.includes('Text') ||
                className.includes('ScrollBar') ||
                className.includes('ScrollView'))) {
            return true;
        }

        if (typeof actor.get_style_class_name === 'function') {
            const styleClass = actor.get_style_class_name();
            if (styleClass &&
                (styleClass.includes('button') ||
                    styleClass.includes('checkbox') ||
                    styleClass.includes('entry'))) {
                return true;
            }
        }
        return false;
    }

    _onButtonPress(event) {
        if (event.get_button() !== 1) {
            return Clutter.EVENT_PROPAGATE;
        }

        if (this._settings.get_boolean('lock-position')) {
            return Clutter.EVENT_PROPAGATE;
        }
        const [x, y] = event.get_coords();
        let actor = global.stage.get_actor_at_pos(Clutter.PickMode.REACTIVE, x, y);
        while (actor && actor !== this) {
            if (this._isInteractive(actor)) {
                return Clutter.EVENT_PROPAGATE;
            }

            actor = actor.get_parent();
        }
        this._dragging = true;
        const [widgetX, widgetY] = this.get_position();
        this._dragX = x - widgetX;
        this._dragY = y - widgetY;
        return Clutter.EVENT_STOP;
    }

    _onMotion(event) {
        if (!this._dragging) {
            return Clutter.EVENT_PROPAGATE;
        }
        const [x, y] = event.get_coords();
        const newX = x - this._dragX;
        const newY = y - this._dragY;
        this.set_position(Math.round(newX), Math.round(newY));
        return Clutter.EVENT_STOP;
    }

    _onButtonRelease(event) {
        if (!this._dragging) {
            return Clutter.EVENT_PROPAGATE;
        }
        this._dragging = false;
        const monitor = Main.layoutManager.primaryMonitor;
        if (monitor) {
            const [x, y] = this.get_position();
            const pctX = (x / monitor.width) * 100;
            const pctY = (y / monitor.height) * 100;
            this._settings.set_double('position-x', pctX);
            this._settings.set_double('position-y', pctY);
        }
        return Clutter.EVENT_STOP;
    }

    destroy() {
        this._clearTimer();
        if (this._fileMonitor) {
            this._fileMonitor.disconnectObject(this);
            this._fileMonitor.cancel();
            this._fileMonitor = null;
        }
        this._settings.disconnectObject(this);
        this.destroy_all_children();
        super.destroy();
    }
});

export default class TodoWidgetExtension extends Extension {
    _widget = null;
    enable() {
        const settings = this.getSettings();
        this._widget = new TodoWidget(settings);
        Main.layoutManager._backgroundGroup.add_child(this._widget);
    }

    disable() {
        if (this._widget) {
            Main.layoutManager._backgroundGroup.remove_child(this._widget);
            this._widget.destroy();
            this._widget = null;
        }
    }
}
